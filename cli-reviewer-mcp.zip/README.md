# CLI Reviewer MCP

An MCP (Model Context Protocol) Server that wraps **Gemini CLI**, **Codex CLI**, and **Claude CLI** as tools — allowing any MCP-compatible AI assistant (Antigravity, Claude Code, Cursor, Windsurf, Cline, etc.) to invoke them for code review and prompting.

---

## Prerequisites

### 1. Node.js (v18+)

```bash
# macOS (Homebrew)
brew install node

# Verify
node --version   # v18.x or later
npm --version
```

### 2. CLI Tools

Install **all three** CLI tools globally. You only need the ones you plan to use, but all three must be resolvable or the corresponding tool will return an error.

```bash
# Gemini CLI
npm install -g @anthropic-ai/gemini-cli
# or via Homebrew:
brew install gemini

# Codex CLI (OpenAI)
npm install -g @openai/codex
# or via Homebrew:
brew install codex

# Claude CLI (Claude Code)
npm install -g @anthropic-ai/claude-code
# or via Homebrew:
brew install claude
```

### 3. Ripgrep (recommended, prevents Gemini CLI warning)

```bash
brew install ripgrep

# Verify
rg --version
```

### 4. CLI Authentication

Each CLI requires its own login/auth **before** use:

```bash
# Gemini — authenticate with Google account
gemini auth login

# Codex — requires OPENAI_API_KEY environment variable
export OPENAI_API_KEY="sk-..."
# Add to ~/.zshrc or ~/.bashrc for persistence:
echo 'export OPENAI_API_KEY="sk-..."' >> ~/.zshrc

# Claude — interactive login
claude /login
# Follow the browser-based authentication flow
```

> **⚠️ Important:** If a CLI is not authenticated, the MCP tool will return an error like `Not logged in · Please run /login`. Make sure to complete authentication before using the MCP server.

---

## Installation

### Step 1: Clone/Copy the package

```bash
# Copy to a permanent location
cp -r cli-reviewer-mcp ~/.gemini/cli-reviewer-mcp
```

### Step 2: Install Node dependencies

```bash
cd ~/.gemini/cli-reviewer-mcp
npm install
```

### Step 3: Verify CLI paths

The server assumes all CLI binaries are at `/opt/homebrew/bin/` (default Homebrew on Apple Silicon). If your setup is different, check and update `index.js`:

```bash
# Find actual paths
which gemini   # e.g., /opt/homebrew/bin/gemini or /usr/local/bin/gemini
which codex    # e.g., /opt/homebrew/bin/codex
which claude   # e.g., /opt/homebrew/bin/claude
```

If paths differ from `/opt/homebrew/bin/`, edit the paths in `index.js` accordingly.

### Step 4: Register in your AI assistant

Add the MCP server to your assistant's configuration file.

**Antigravity** (`~/.gemini/antigravity/mcp_config.json`):
```json
{
  "mcpServers": {
    "cli-reviewer-mcp": {
      "command": "node",
      "args": [
        "/Users/<username>/.gemini/cli-reviewer-mcp/index.js"
      ]
    }
  }
}
```

**Claude Code** (`~/.claude/mcp.json`):
```json
{
  "mcpServers": {
    "cli-reviewer-mcp": {
      "command": "node",
      "args": [
        "/Users/<username>/.gemini/cli-reviewer-mcp/index.js"
      ]
    }
  }
}
```

**Cursor / Windsurf / Cline** — refer to their MCP documentation for the config file location, then add the same `command` + `args` block.

> Replace `/Users/<username>/` with your actual home directory path.

### Step 5: Restart your AI assistant

The MCP server is launched as a subprocess. You must **restart** the assistant (or reload MCP servers) for changes to take effect.

---

## Included Tools

### `gemini_cli`

Send prompts to Gemini CLI.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `prompt` | string | ✅ | The prompt to send |
| `cwd` | string | ❌ | Working directory |

### `codex_review`

Use Codex to review files, artifacts, or uncommitted git changes.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `target_type` | `workspace_uncommitted` \| `file` \| `artifact` | ✅ | What to review |
| `target_path` | string | When `file`/`artifact` | Absolute path to the file |
| `prompt` | string | ❌ | Custom review instructions |
| `cwd` | string | ❌ | Working directory (**must be a git repo** for `workspace_uncommitted`) |

> **Note:** `codex review --uncommitted` requires the `cwd` to be inside a trusted git repository. If you get `Not inside a trusted directory`, set `cwd` to your project root.

### `claude_cli`

Send prompts to Claude via non-interactive mode (`claude -p`).

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `prompt` | string | ✅ | The prompt to send |
| `cwd` | string | ❌ | Working directory |

---

## Configuration

### Timeout & Buffer

All tools are configured with:
- **Timeout:** 120 seconds (2 minutes)
- **Max buffer:** 10 MB

These values are defined in `index.js`. Increase them if you work with very large codebases or slow models.

### Stderr Filtering

Known non-actionable warnings are automatically filtered from tool output:

| Tool | Filtered warnings |
|------|-------------------|
| Gemini | `256-color support`, `True color`, `Ripgrep is not available` |
| Codex | Session banner (`OpenAI Codex`, `workdir`, `model`, etc.), `codex_core::session` errors |
| Claude | `no stdin data received` |

---

## Troubleshooting

### `Error executing gemini: Command failed`
- **Cause:** Gemini CLI not installed or not at `/opt/homebrew/bin/gemini`
- **Fix:** Run `which gemini` and update the path in `index.js`

### `Not logged in · Please run /login`
- **Cause:** Claude CLI not authenticated
- **Fix:** Run `claude` in terminal, then type `/login` and complete the auth flow

### `Not inside a trusted directory`
- **Cause:** Codex requires the `cwd` to be a git repo
- **Fix:** Set `cwd` to your project root (which has a `.git` folder)

### `OPENAI_API_KEY is not set`
- **Cause:** Codex requires an OpenAI API key
- **Fix:** `export OPENAI_API_KEY="sk-..."` in your shell profile

### Tool output contains unexpected warnings
- **Cause:** New CLI version added new warnings
- **Fix:** Add the warning text to the `filteredStderr` filter in `index.js`

### MCP server not loading after code changes
- **Cause:** The AI assistant caches the MCP server process
- **Fix:** Restart the AI assistant to reload the MCP server

---

## File Structure

```
cli-reviewer-mcp/
├── index.js          # MCP server implementation
├── package.json      # Node.js dependencies
├── package-lock.json # Locked dependency versions
├── node_modules/     # Installed dependencies (after npm install)
└── README.md         # This file
```
